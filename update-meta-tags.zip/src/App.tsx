import { useState } from "react";
import { cn } from "./utils/cn";

// Types
interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviews: number;
  discount: string;
  location: string;
  badge?: string;
  icon: string;
}

interface Category {
  name: string;
  icon: string;
}

interface Benefit {
  icon: string;
  title: string;
  text: string;
}

// Sample Data
const products: Product[] = [
  {
    id: 1,
    name: "ZULFYRA LED Desk Lamp with Wireless Charger - Eye Protection Study Lamp",
    price: 159.00,
    originalPrice: 229.00,
    rating: 4.8,
    reviews: 234,
    discount: "31% OFF",
    location: "Kuala Lumpur",
    badge: "Best Seller",
    icon: "💡",
  },
  {
    id: 2,
    name: "ZULFYRA Pro LED Study Lamp - 5 Brightness Levels with USB Port",
    price: 129.00,
    originalPrice: 189.00,
    rating: 4.7,
    reviews: 189,
    discount: "32% OFF",
    location: "Selangor",
    icon: "🔦",
  },
  {
    id: 3,
    name: "ZULFYRA Foldable LED Desk Lamp - Portable Eye Care Reading Lamp",
    price: 89.00,
    originalPrice: 139.00,
    rating: 4.6,
    reviews: 156,
    discount: "36% OFF",
    location: "Penang",
    icon: "🪔",
  },
  {
    id: 4,
    name: "ZULFYRA Smart LED Lamp - App Control RGB Lighting Desk Lamp",
    price: 199.00,
    originalPrice: 279.00,
    rating: 4.9,
    reviews: 98,
    discount: "29% OFF",
    location: "Johor Bahru",
    badge: "New",
    icon: "💫",
  },
  {
    id: 5,
    name: "ZULFYRA Kids Study Lamp - Cute Animal Design LED Reading Lamp",
    price: 79.00,
    originalPrice: 119.00,
    rating: 4.5,
    reviews: 312,
    discount: "34% OFF",
    location: "Kuala Lumpur",
    icon: "🐼",
  },
  {
    id: 6,
    name: "ZULFYRA Architect LED Lamp - Adjustable Arm Design Studio Light",
    price: 249.00,
    originalPrice: 349.00,
    rating: 4.8,
    reviews: 67,
    discount: "29% OFF",
    location: "Selangor",
    icon: "🏗️",
  },
  {
    id: 7,
    name: "ZULFYRA简约LED台灯 - Modern Minimalist Desk Lamp for Home Office",
    price: 139.00,
    originalPrice: 199.00,
    rating: 4.7,
    reviews: 145,
    discount: "30% OFF",
    location: "Shah Alam",
    icon: "✨",
  },
  {
    id: 8,
    name: "ZULFYRA clamp LED Lamp - Space Saving Clip On Desk Light",
    price: 99.00,
    originalPrice: 149.00,
    rating: 4.6,
    reviews: 89,
    discount: "34% OFF",
    location: "Subang Jaya",
    icon: "📎",
  },
];

const categories: Category[] = [
  { name: "LED Desk Lamps", icon: "💡" },
  { name: "Eye Care Lamps", icon: "👁️" },
  { name: "Wireless Charger", icon: "🔋" },
  { name: "Kids Study Lamps", icon: "🎒" },
  { name: "Architect Lamps", icon: "📐" },
  { name: "Portable Lamps", icon: "🔦" },
  { name: "Smart Lamps", icon: "📱" },
  { name: "Clip On Lamps", icon: "🖥️" },
];

const benefits: Benefit[] = [
  {
    icon: "🚚",
    title: "Free Shipping",
    text: "Free shipping on orders over RM150",
  },
  {
    icon: "🛡️",
    title: "1 Year Warranty",
    text: "Comprehensive product warranty",
  },
  {
    icon: "↩️",
    title: "Easy Returns",
    text: "30-day hassle-free returns",
  },
  {
    icon: "💬",
    title: "24/7 Support",
    text: "Dedicated customer support",
  },
  {
    icon: "✓",
    title: "Quality Certified",
    text: "ISO 9001 certified products",
  },
  {
    icon: "🔒",
    title: "Secure Payment",
    text: "SSL encrypted transactions",
  },
];

// Components
function StarRating({ rating, reviewCount }: { rating: number; reviewCount: number }) {
  return (
    <div className="flex items-center gap-1">
      <div className="flex text-yellow-500 text-xs">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star} className={star <= rating ? "text-yellow-500" : "text-gray-300"}>
            ★
          </span>
        ))}
      </div>
      <span className="text-gray-500 text-xs ml-1">({reviewCount})</span>
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div
      className={cn(
        "bg-white rounded-lg border border-gray-200 overflow-hidden transition-all duration-300 cursor-pointer",
        isHovered ? "shadow-xl -translate-y-2 border-gray-800" : "",
        "shadow-sm"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-56 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
        <span className="text-7xl">{product.icon}</span>
        {product.badge && (
          <span className="absolute top-3 right-3 bg-gradient-to-r from-red-500 to-red-600 text-white px-2 py-1 rounded text-xs font-bold uppercase shadow-md">
            {product.badge}
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-sm font-semibold text-gray-800 mb-2 line-clamp-2 hover:text-red-500 transition-colors leading-relaxed">
          {product.name}
        </h3>
        <StarRating rating={product.rating} reviewCount={product.reviews} />
        <div className="mt-2">
          <span className="text-xl font-bold text-red-500">RM{product.price.toFixed(2)}</span>
          <span className="text-gray-400 line-through text-xs ml-2">RM{product.originalPrice.toFixed(2)}</span>
        </div>
        <p className="text-red-500 text-xs font-bold uppercase mt-1">{product.discount}</p>
        <p className="text-gray-500 text-xs mt-2">{product.location}</p>
        <button
          onClick={handleAddToCart}
          className={cn(
            "w-full mt-3 py-2.5 rounded font-semibold text-sm uppercase tracking-wide transition-all duration-200",
            isAdded
              ? "bg-green-500 text-white"
              : "bg-gradient-to-r from-gray-800 to-gray-700 text-white hover:shadow-lg hover:scale-[1.02]"
          )}
        >
          {isAdded ? "Added to Cart!" : "Add to Cart"}
        </button>
      </div>
    </div>
  );
}

function Header() {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <header className="bg-white border-b-2 border-gray-800 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <a href="#" className="text-3xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
              ⚡ ZULFYRA
            </a>
            <span className="text-xs text-gray-500 font-semibold tracking-wide">SMART STUDY LAMPS</span>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-xl flex gap-2">
            <input
              type="text"
              placeholder="Search for study lamps..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-4 py-2.5 border-2 border-gray-200 rounded-lg text-sm focus:outline-none focus:border-gray-800 transition-colors"
            />
            <button className="px-6 py-2.5 bg-gradient-to-r from-gray-800 to-gray-700 text-white rounded-lg font-semibold text-sm hover:shadow-lg hover:scale-[1.02] transition-all duration-200">
              Search
            </button>
          </div>

          {/* User Menu */}
          <div className="flex items-center gap-5 flex-shrink-0 text-sm">
            <a href="#" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">Sign In</a>
            <a href="#" className="text-gray-700 hover:text-gray-900 font-medium transition-colors">Help</a>
            <a href="#" className="text-2xl">🛒</a>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-gradient-to-r from-gray-100 to-gray-50 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex gap-6 overflow-x-auto flex-wrap">
          {[
            "All Products",
            "LED Desk Lamps",
            "Eye Care Series",
            "Wireless Charger",
            "Kids Collection",
            "Architect Series",
            "Smart WiFi",
            "Accessories",
            "Sale",
          ].map((item, index) => (
            <a
              key={index}
              href="#"
              className="text-gray-700 hover:text-gray-900 font-semibold text-xs uppercase tracking-wide whitespace-nowrap py-1 border-b-2 border-transparent hover:border-gray-800 transition-all duration-200"
            >
              {item}
            </a>
          ))}
        </div>
      </nav>
    </header>
  );
}

function Banner() {
  return (
    <section className="bg-gradient-to-r from-gray-800 via-gray-700 to-gray-500 text-white py-16 px-4 mb-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(255,255,255,0.1),transparent_50%)]" />
      <div className="max-w-7xl mx-auto text-center relative z-10">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight">Premium Study Lamps for Better Learning</h1>
        <p className="text-lg md:text-xl mb-6 opacity-95">Engineered for comfort, designed for success</p>
        <div className="flex gap-3 justify-center flex-wrap">
          <button className="px-8 py-3 bg-red-500 border-2 border-red-500 rounded-lg font-semibold text-sm hover:bg-red-600 hover:border-red-600 transition-all duration-200">
            Shop Now
          </button>
          <button className="px-8 py-3 border-2 border-white rounded-lg font-semibold text-sm hover:bg-white hover:text-gray-800 transition-all duration-200">
            Learn More
          </button>
        </div>
      </div>
    </section>
  );
}

function OfferBanner() {
  return (
    <section className="max-w-7xl mx-auto px-4 mb-10">
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-lg p-6 text-center text-white shadow-lg">
        <h2 className="text-2xl font-bold mb-2">🎉 Flash Sale! 40% OFF All LED Lamps</h2>
        <p className="opacity-95">Limited time offer. Free shipping on orders above RM100.</p>
      </div>
    </section>
  );
}

function Benefits() {
  return (
    <section className="max-w-7xl mx-auto px-4 mb-12">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {benefits.map((benefit, index) => (
          <div
            key={index}
            className="bg-white p-5 rounded-lg text-center border-2 border-gray-100 hover:border-gray-800 transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-1"
          >
            <span className="text-3xl block mb-2">{benefit.icon}</span>
            <h3 className="font-bold text-gray-800 text-sm mb-1">{benefit.title}</h3>
            <p className="text-gray-500 text-xs">{benefit.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Categories() {
  return (
    <section className="max-w-7xl mx-auto px-4 mb-12">
      <h2 className="text-2xl font-bold mb-6 pb-2 border-b-4 border-gray-800 inline-block">Shop by Category</h2>
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {categories.map((category, index) => (
          <div
            key={index}
            className="bg-white p-4 rounded-lg text-center cursor-pointer border-2 border-gray-100 hover:border-gray-800 transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-1"
          >
            <span className="text-3xl block mb-2">{category.icon}</span>
            <span className="font-semibold text-gray-800 text-xs">{category.name}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Filters() {
  return (
    <aside className="hidden lg:block bg-white p-5 rounded-lg h-fit border border-gray-200 shadow-sm">
      <div className="space-y-5">
        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-3">Category</h3>
          {["LED Desk Lamps", "Eye Care Lamps", "Wireless Charger", "Kids Study Lamps"].map((item, index) => (
            <label key={index} className="flex items-center gap-2 mb-2 cursor-pointer">
              <input type="checkbox" className="accent-gray-800 w-4 h-4" />
              <span className="text-sm text-gray-600">{item}</span>
            </label>
          ))}
        </div>
        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-3">Price Range</h3>
          {["Under RM50", "RM50 - RM100", "RM100 - RM200", "Above RM200"].map((item, index) => (
            <label key={index} className="flex items-center gap-2 mb-2 cursor-pointer">
              <input type="checkbox" className="accent-gray-800 w-4 h-4" />
              <span className="text-sm text-gray-600">{item}</span>
            </label>
          ))}
        </div>
        <div>
          <h3 className="font-bold text-gray-800 text-sm uppercase tracking-wide mb-3">Rating</h3>
          {[4, 3, 2, 1].map((stars) => (
            <label key={stars} className="flex items-center gap-2 mb-2 cursor-pointer">
              <input type="checkbox" className="accent-gray-800 w-4 h-4" />
              <div className="flex text-yellow-500 text-xs">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span key={star} className={star <= stars ? "text-yellow-500" : "text-gray-300"}>
                    ★
                  </span>
                ))}
              </div>
              <span className="text-sm text-gray-600">& Up</span>
            </label>
          ))}
        </div>
      </div>
    </aside>
  );
}

function ProductsSection() {
  return (
    <section className="max-w-7xl mx-auto px-4 mb-12">
      <div className="flex items-end justify-between mb-6">
        <h2 className="text-2xl font-bold pb-2 border-b-4 border-gray-800 inline-block">Featured Products</h2>
        <a href="#" className="text-gray-700 font-semibold text-sm hover:text-gray-900 transition-colors">
          View All →
        </a>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}

function ContactInfo() {
  return (
    <section className="max-w-7xl mx-auto px-4 mb-10">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg p-6 border-l-4 border-gray-800">
        <h3 className="font-bold text-gray-800 text-lg mb-3">Contact Us</h3>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <p>
            📧 <span className="font-semibold">Email:</span>{" "}
            <a href="mailto:support@zulfyra.com" className="text-gray-700 hover:text-red-500 transition-colors">
              support@zulfyra.com
            </a>
          </p>
          <p>
            📞 <span className="font-semibold">Phone:</span>{" "}
            <a href="tel:+60123456789" className="text-gray-700 hover:text-red-500 transition-colors">
              +60 12-345 6789
            </a>
          </p>
          <p>
            📍 <span className="font-semibold">Location:</span> Kuala Lumpur, Malaysia
          </p>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-gradient-to-r from-gray-800 to-gray-700 text-white pt-12 pb-6 mt-16">
      <div className="max-w-7xl mx-auto px-4 mb-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <h3 className="font-bold text-sm uppercase tracking-wide mb-4">About Us</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Our Story</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Careers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Press</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Blog</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-sm uppercase tracking-wide mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">FAQs</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Shipping Info</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Returns</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-sm uppercase tracking-wide mb-4">Products</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">All Products</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">New Arrivals</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Best Sellers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Sale</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-sm uppercase tracking-wide mb-4">Connect</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Facebook</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Instagram</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">Twitter</a></li>
              <li><a href="#" className="text-gray-300 hover:text-amber-400 transition-colors">YouTube</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 pt-6 border-t border-gray-600 text-center text-sm text-gray-400">
        <p>© 2024 ZULFYRA Malaysia. All rights reserved.</p>
        <p className="mt-1">Premium Smart Study Lamps | Eye-Protective LED Lighting</p>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Banner />
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-6">
          <Filters />
          <main className="flex-1">
            <OfferBanner />
            <Benefits />
            <Categories />
            <ProductsSection />
            <ContactInfo />
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
